# PRÉDICT — Marchés Prédictifs IA

Site de marchés prédictifs propulsé par Claude AI.
Dépôts via PayPal, MonCash, NatCash, Carte bancaire.

---

## 🚀 Démarrage rapide

### 1. Installe les dépendances
```bash
npm install
```

### 2. Configure ta clé API (pour l'IA)
```bash
cp .env.example .env
```
Ouvre `.env` et remplace `sk-ant-XXX` par ta vraie clé API Anthropic.
👉 Obtiens-la sur : https://console.anthropic.com

### 3. Lance en local
```bash
npm run dev
```
Ouvre http://localhost:5173

---

## 🌐 Déploiement sur Vercel (gratuit)

### Option A — Via terminal
```bash
npm install -g vercel
vercel
```
Suis les instructions. Ton site sera en ligne en 2 minutes.

### Option B — Via GitHub (recommandé)
1. Crée un compte sur https://github.com
2. Crée un nouveau dépôt et pousse le code :
```bash
git init
git add .
git commit -m "Premier déploiement PRÉDICT"
git remote add origin https://github.com/TON_USER/predict-market.git
git push -u origin main
```
3. Va sur https://vercel.com → "Import Git Repository"
4. Sélectionne ton dépôt → Deploy
5. Dans Vercel → Settings → Environment Variables :
   - Ajoute `VITE_ANTHROPIC_KEY` = ta clé API

✅ Ton site est en ligne sur `predict-market.vercel.app` !

---

## 🔑 Clé API Anthropic

Sans clé API :
- ✅ Paris, dépôts, filtres, classement, historique → tout fonctionne
- ❌ Génération de marchés par IA → erreur

Avec clé API → tout fonctionne à 100%.

---

## 📦 Structure du projet

```
predict-market/
├── index.html          ← Page HTML principale
├── vite.config.js      ← Config Vite
├── vercel.json         ← Config déploiement Vercel
├── package.json        ← Dépendances
├── .env.example        ← Modèle pour la clé API
└── src/
    ├── main.jsx        ← Point d'entrée React
    └── App.jsx         ← Application complète
```

## 🛠 Technologies
- React 18 + Vite
- Recharts (graphiques)
- Claude API (génération de marchés + analyse IA)
