import { useState, useRef, useEffect } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, ReferenceLine } from "recharts";

const CLAUDE_API = "https://api.anthropic.com/v1/messages";
const API_KEY = import.meta.env.VITE_ANTHROPIC_KEY || "";

// ── HELPERS ──────────────────────────────────────────────────────────────────
function genHistory(base) {
  const pts = [];
  let v = base;
  const now = Date.now();
  for (let i = 29; i >= 0; i--) {
    v = Math.max(0.05, Math.min(0.95, v + (Math.random() - 0.48) * 0.04));
    pts.push({ day: `J-${i}`, prob: Math.round(v * 100), ts: now - i * 86400000 });
  }
  return pts;
}

function formatVol(n) {
  if (n >= 1e6) return `${(n / 1e6).toFixed(1)}M`;
  if (n >= 1000) return `${(n / 1000).toFixed(0)}k`;
  return n;
}
function timeAgo(ts) {
  const s = Math.floor((Date.now() - ts) / 1000);
  if (s < 60) return "à l'instant";
  if (s < 3600) return `il y a ${Math.floor(s / 60)}min`;
  if (s < 86400) return `il y a ${Math.floor(s / 3600)}h`;
  return `il y a ${Math.floor(s / 86400)}j`;
}

// ── SEED DATA ────────────────────────────────────────────────────────────────
const INIT_MARKETS = [
  { id: 1, question: "La France va-t-elle gagner la prochaine Coupe du Monde ?", category: "Sport", yesProb: 0.34, volume: 142500, closes: "2026-12-01", userBet: null, comments: [{ user: "Alex", text: "Les Bleus ont une belle génération !", ts: Date.now() - 3600000, likes: 4 }, { user: "Marie", text: "Dépend des blessures avant le tournoi…", ts: Date.now() - 1800000, likes: 2 }], history: genHistory(0.34) },
  { id: 2, question: "L'IA va-t-elle dépasser l'humain au jeu de Go d'ici 2027 ?", category: "Technologie", yesProb: 0.71, volume: 89300, closes: "2027-01-01", userBet: null, comments: [{ user: "Léo", text: "AlphaGo l'a déjà fait non ?", ts: Date.now() - 7200000, likes: 8 }], history: genHistory(0.71) },
  { id: 3, question: "Bitcoin dépassera-t-il 200 000 $ avant fin 2026 ?", category: "Finance", yesProb: 0.52, volume: 310000, closes: "2026-12-31", userBet: null, comments: [{ user: "Crypto_Fan", text: "Le halving va tout changer 🚀", ts: Date.now() - 600000, likes: 12 }, { user: "Sceptik", text: "La régulation va freiner la hausse.", ts: Date.now() - 300000, likes: 5 }], history: genHistory(0.52) },
];

const LEADERBOARD_SEED = [
  { rank: 1, user: "CryptoKing", avatar: "👑", profit: 4820, bets: 34, winRate: 71 },
  { rank: 2, user: "Stratège_Haïti", avatar: "🎯", profit: 3150, bets: 28, winRate: 64 },
  { rank: 3, user: "FutureVisor", avatar: "🔮", profit: 2740, bets: 19, winRate: 68 },
  { rank: 4, user: "TechOracle", avatar: "🤖", profit: 1990, bets: 41, winRate: 56 },
  { rank: 5, user: "MarketWizard", avatar: "🧙", profit: 1430, bets: 22, winRate: 59 },
];

const PAYMENT_METHODS = [
  { id: "paypal", name: "PayPal", icon: "🅿", color: "#003087", accent: "#009cde", fields: [{ key: "email", label: "Email PayPal", placeholder: "votre@email.com", type: "email" }], fee: 2.9, feeFixed: 0.30, delay: "Instantané" },
  { id: "moncash", name: "MonCash", icon: "🇭🇹", color: "#e8131b", accent: "#ff4d55", fields: [{ key: "phone", label: "Numéro MonCash", placeholder: "+509 XXXX XXXX", type: "tel" }], fee: 1.5, feeFixed: 0, delay: "Instantané" },
  { id: "natcash", name: "NatCash", icon: "🏦", color: "#1a5276", accent: "#2e86c1", fields: [{ key: "phone", label: "Numéro NatCash", placeholder: "+509 XXXX XXXX", type: "tel" }], fee: 1.0, feeFixed: 0, delay: "< 5 min" },
  { id: "card", name: "Carte Bancaire", icon: "💳", color: "#1e1e2e", accent: "#7c3aed", fields: [{ key: "cardNumber", label: "Numéro de carte", placeholder: "1234 5678 9012 3456", type: "text", maxLen: 19 }, { key: "expiry", label: "Expiration", placeholder: "MM/AA", type: "text", maxLen: 5, half: true }, { key: "cvv", label: "CVV", placeholder: "123", type: "text", maxLen: 3, half: true }, { key: "name", label: "Nom sur la carte", placeholder: "JEAN DUPONT", type: "text" }], fee: 1.5, feeFixed: 0, delay: "Instantané" },
];

const CAT_COLORS = { Sport: "#3b82f6", Technologie: "#a855f7", Finance: "#f59e0b", Politique: "#ef4444", Science: "#10b981", Culture: "#ec4899" };

// ── PROB BAR ─────────────────────────────────────────────────────────────────
function ProbBar({ prob }) {
  const pct = Math.round(prob * 100);
  return (
    <div style={{ position: "relative", height: 6, background: "#1a1f2e", borderRadius: 3, overflow: "hidden" }}>
      <div style={{ position: "absolute", left: 0, top: 0, height: "100%", width: `${pct}%`, background: pct > 60 ? "#00e5a0" : pct > 40 ? "#f5c842" : "#ff4d6d", borderRadius: 3, transition: "width 0.6s cubic-bezier(0.34,1.56,0.64,1)" }} />
    </div>
  );
}

// ── CHART TOOLTIP ─────────────────────────────────────────────────────────────
function ChartTip({ active, payload }) {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background: "#161b27", border: "1px solid #1e2736", borderRadius: 8, padding: "6px 12px", fontSize: 12, fontFamily: "'Space Mono', monospace" }}>
      <div style={{ color: "#00e5a0", fontWeight: 700 }}>{payload[0].value}%</div>
      <div style={{ color: "#4a5568" }}>{payload[0].payload.day}</div>
    </div>
  );
}

// ── DEPOSIT MODAL ─────────────────────────────────────────────────────────────
function DepositModal({ onClose, onDeposit }) {
  const [step, setStep] = useState("method");
  const [selected, setSelected] = useState(null);
  const [amount, setAmount] = useState(50);
  const [fields, setFields] = useState({});
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const method = PAYMENT_METHODS.find(m => m.id === selected);
  const feeAmt = method ? ((amount * method.fee / 100) + method.feeFixed).toFixed(2) : "0.00";
  const total = method ? (amount + parseFloat(feeAmt)).toFixed(2) : amount.toFixed(2);

  function handleField(key, val) {
    let v = val;
    if (key === "cardNumber") v = val.replace(/\D/g, "").slice(0, 16).replace(/(.{4})/g, "$1 ").trim();
    if (key === "expiry") { const d = val.replace(/\D/g, "").slice(0, 4); v = d.length > 2 ? d.slice(0, 2) + "/" + d.slice(2) : d; }
    setFields(f => ({ ...f, [key]: v }));
    setErrors(e => ({ ...e, [key]: null }));
  }

  function validate() {
    const errs = {};
    method.fields.forEach(f => { if (!fields[f.key]?.trim()) errs[f.key] = "Requis"; });
    if (method.id === "card") {
      if ((fields.cardNumber || "").replace(/\s/g, "").length < 16) errs.cardNumber = "Numéro invalide";
      if (!/^\d{2}\/\d{2}$/.test(fields.expiry || "")) errs.expiry = "MM/AA";
      if ((fields.cvv || "").length < 3) errs.cvv = "3 chiffres";
    }
    if (["moncash", "natcash"].includes(method.id) && (fields.phone || "").replace(/\D/g, "").length < 8) errs.phone = "Invalide";
    if (method.id === "paypal" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(fields.email || "")) errs.email = "Email invalide";
    setErrors(errs);
    return !Object.keys(errs).length;
  }

  async function submit() {
    if (!validate()) return;
    setLoading(true);
    await new Promise(r => setTimeout(r, 1800));
    setLoading(false);
    setStep("success");
    setTimeout(() => { onDeposit(amount); onClose(); }, 2200);
  }

  return (
    <div style={{ position: "fixed", inset: 0, zIndex: 200, background: "rgba(0,0,0,0.8)", backdropFilter: "blur(8px)", display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }} onClick={onClose}>
      <div style={{ background: "#0d1117", border: "1px solid #1e2736", borderRadius: 24, width: "100%", maxWidth: 460, maxHeight: "90vh", overflowY: "auto", boxShadow: "0 24px 80px rgba(0,0,0,0.6)", animation: "fadeIn 0.3s ease" }} onClick={e => e.stopPropagation()}>
        <div style={{ padding: "20px 24px 16px", borderBottom: "1px solid #1e2736", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div style={{ fontSize: 17, fontWeight: 800, color: "#e2e8f0", fontFamily: "'Space Mono', monospace" }}>{step === "success" ? "✓ Dépôt confirmé !" : "Déposer des fonds"}</div>
          <button onClick={onClose} style={{ background: "#1e2736", border: "none", borderRadius: 8, color: "#64748b", width: 30, height: 30, cursor: "pointer", fontSize: 14 }}>✕</button>
        </div>
        <div style={{ padding: "20px 24px 24px" }}>
          {step === "method" && (
            <>
              <div style={{ marginBottom: 18 }}>
                <div style={{ fontSize: 11, color: "#64748b", fontFamily: "'Space Mono', monospace", marginBottom: 8 }}>MONTANT</div>
                <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 10 }}>
                  {[10, 25, 50, 100, 250].map(p => (
                    <button key={p} onClick={() => setAmount(p)} style={{ padding: "7px 14px", borderRadius: 8, fontSize: 12, fontWeight: 700, cursor: "pointer", fontFamily: "'Space Mono', monospace", background: amount === p ? "#00e5a0" : "#161b27", color: amount === p ? "#000" : "#64748b", border: `1px solid ${amount === p ? "#00e5a0" : "#1e2736"}`, transition: "all 0.15s" }}>${p}</button>
                  ))}
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <span style={{ color: "#4a5568", fontFamily: "'Space Mono', monospace" }}>$</span>
                  <input type="number" min={1} value={amount} onChange={e => setAmount(Math.max(1, +e.target.value))} style={{ flex: 1, background: "#161b27", border: "1px solid #1e2736", borderRadius: 10, padding: "10px 14px", color: "#e2e8f0", fontSize: 18, fontWeight: 800, fontFamily: "'Space Mono', monospace", outline: "none" }} />
                </div>
              </div>
              <div style={{ fontSize: 11, color: "#64748b", fontFamily: "'Space Mono', monospace", marginBottom: 10 }}>MÉTHODE</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                {PAYMENT_METHODS.map(pm => (
                  <button key={pm.id} onClick={() => { setSelected(pm.id); setStep("form"); setFields({}); setErrors({}); }} style={{ display: "flex", alignItems: "center", gap: 14, padding: "13px 16px", background: "#161b27", border: "1px solid #1e2736", borderRadius: 14, cursor: "pointer", textAlign: "left", width: "100%", transition: "all 0.2s" }}
                    onMouseEnter={e => { e.currentTarget.style.borderColor = pm.accent; e.currentTarget.style.background = `${pm.accent}12`; }}
                    onMouseLeave={e => { e.currentTarget.style.borderColor = "#1e2736"; e.currentTarget.style.background = "#161b27"; }}>
                    <div style={{ width: 40, height: 40, borderRadius: 10, background: `linear-gradient(135deg, ${pm.color}, ${pm.accent})`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18 }}>{pm.icon}</div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 14, fontWeight: 700, color: "#e2e8f0" }}>{pm.name}</div>
                      <div style={{ fontSize: 11, color: "#4a5568" }}>Frais: {pm.fee}%{pm.feeFixed ? ` + $${pm.feeFixed}` : ""} • {pm.delay}</div>
                    </div>
                    <span style={{ color: "#4a5568" }}>›</span>
                  </button>
                ))}
              </div>
            </>
          )}
          {step === "form" && method && (
            <>
              <button onClick={() => setStep("method")} style={{ background: "transparent", border: "none", color: "#64748b", cursor: "pointer", fontSize: 13, padding: 0, marginBottom: 16, fontFamily: "'Sora', sans-serif" }}>‹ Retour</button>
              <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 16px", background: `${method.accent}15`, border: `1px solid ${method.accent}30`, borderRadius: 12, marginBottom: 18 }}>
                <div style={{ width: 36, height: 36, borderRadius: 10, background: `linear-gradient(135deg, ${method.color}, ${method.accent})`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18 }}>{method.icon}</div>
                <div><div style={{ fontSize: 13, fontWeight: 700, color: "#e2e8f0" }}>{method.name}</div><div style={{ fontSize: 11, color: "#64748b" }}>Dépôt de <span style={{ color: method.accent, fontWeight: 700 }}>${amount}</span></div></div>
              </div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 12, marginBottom: 18 }}>
                {method.fields.map(f => (
                  <div key={f.key} style={{ width: f.half ? "calc(50% - 6px)" : "100%" }}>
                    <label style={{ fontSize: 11, color: "#64748b", fontFamily: "'Space Mono', monospace", display: "block", marginBottom: 6 }}>{f.label}</label>
                    <input type={f.type} placeholder={f.placeholder} value={fields[f.key] || ""} maxLength={f.maxLen} onChange={e => handleField(f.key, e.target.value)}
                      style={{ width: "100%", background: "#080c14", border: `1px solid ${errors[f.key] ? "#ff4d6d" : "#1e2736"}`, borderRadius: 10, padding: "10px 14px", color: "#e2e8f0", fontSize: 14, fontFamily: "'Space Mono', monospace", outline: "none" }} />
                    {errors[f.key] && <div style={{ fontSize: 11, color: "#ff4d6d", marginTop: 3 }}>{errors[f.key]}</div>}
                  </div>
                ))}
              </div>
              <div style={{ background: "#080c14", border: "1px solid #1e2736", borderRadius: 12, padding: "12px 16px", marginBottom: 16 }}>
                {[{ l: "Montant", v: `$${amount.toFixed(2)}` }, { l: `Frais (${method.fee}%)`, v: `$${feeAmt}`, sub: true }, { l: "Total débité", v: `$${total}`, bold: true }].map(r => (
                  <div key={r.l} style={{ display: "flex", justifyContent: "space-between", marginBottom: r.bold ? 0 : 7, paddingTop: r.bold ? 7 : 0, borderTop: r.bold ? "1px solid #1e2736" : "none" }}>
                    <span style={{ fontSize: 12, color: r.sub ? "#4a5568" : "#94a3b8" }}>{r.l}</span>
                    <span style={{ fontSize: 13, fontWeight: r.bold ? 800 : 500, color: r.bold ? "#00e5a0" : "#94a3b8", fontFamily: "'Space Mono', monospace" }}>{r.v}</span>
                  </div>
                ))}
              </div>
              <button onClick={submit} disabled={loading} style={{ width: "100%", padding: "13px 0", background: loading ? "#1e2736" : `linear-gradient(135deg, ${method.accent}, ${method.color})`, color: loading ? "#4a5568" : "#fff", border: "none", borderRadius: 12, fontWeight: 800, fontSize: 14, cursor: loading ? "not-allowed" : "pointer", fontFamily: "'Space Mono', monospace" }}>
                {loading ? <span style={{ animation: "pulse 1s infinite", display: "inline-block" }}>TRAITEMENT…</span> : `CONFIRMER • $${total}`}
              </button>
              <div style={{ textAlign: "center", marginTop: 10, fontSize: 11, color: "#4a5568" }}>🔒 Paiement sécurisé</div>
            </>
          )}
          {step === "success" && (
            <div style={{ textAlign: "center", padding: "20px 0" }}>
              <div style={{ width: 70, height: 70, borderRadius: "50%", background: "rgba(0,229,160,0.12)", border: "2px solid #00e5a0", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 30, margin: "0 auto 16px" }}>✓</div>
              <div style={{ fontSize: 20, fontWeight: 800, color: "#00e5a0", fontFamily: "'Space Mono', monospace", marginBottom: 8 }}>+${amount} crédités !</div>
              <div style={{ fontSize: 13, color: "#64748b" }}>Bonne chance sur les marchés !</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ── MARKET DETAIL MODAL ───────────────────────────────────────────────────────
function MarketDetail({ market, onClose, onBet, currentUser }) {
  const [side, setSide] = useState("yes");
  const [amount, setAmount] = useState(10);
  const [comment, setComment] = useState("");
  const [comments, setComments] = useState(market.comments || []);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState("");
  const pct = Math.round(market.yesProb * 100);

  async function getAiAnalysis() {
    setAiLoading(true);
    try {
      const res = await fetch(CLAUDE_API, {
        method: "POST", headers: { "Content-Type": "application/json", "x-api-key": API_KEY, "anthropic-version": "2023-06-01", "anthropic-dangerous-direct-browser-access": "true" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514", max_tokens: 300,
          messages: [{ role: "user", content: `Analyse brièvement ce marché prédictif en 3-4 phrases: "${market.question}". Probabilité actuelle: ${pct}%. Volume: $${formatVol(market.volume)}. Donne une analyse factuelle et mentionne les facteurs clés à surveiller. Réponds en français.` }]
        })
      });
      const data = await res.json();
      setAiAnalysis(data.content?.find(b => b.type === "text")?.text || "Analyse indisponible.");
    } catch { setAiAnalysis("Analyse indisponible pour le moment."); }
    setAiLoading(false);
  }

  function addComment() {
    if (!comment.trim()) return;
    setComments(c => [...c, { user: currentUser, text: comment, ts: Date.now(), likes: 0 }]);
    setComment("");
  }

  return (
    <div style={{ position: "fixed", inset: 0, zIndex: 150, background: "rgba(0,0,0,0.85)", backdropFilter: "blur(10px)", display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }} onClick={onClose}>
      <div style={{ background: "#0d1117", border: "1px solid #1e2736", borderRadius: 24, width: "100%", maxWidth: 620, maxHeight: "92vh", overflowY: "auto", boxShadow: "0 24px 80px rgba(0,0,0,0.7)", animation: "fadeIn 0.3s ease" }} onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div style={{ padding: "20px 24px 16px", borderBottom: "1px solid #1e2736", display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12 }}>
          <div style={{ flex: 1 }}>
            <span style={{ fontSize: 10, fontWeight: 700, color: CAT_COLORS[market.category] || "#6b7280", background: `${CAT_COLORS[market.category] || "#6b7280"}18`, padding: "2px 8px", borderRadius: 20, fontFamily: "'Space Mono', monospace" }}>{market.category}</span>
            <div style={{ fontSize: 16, fontWeight: 700, color: "#e2e8f0", marginTop: 8, lineHeight: 1.4, fontFamily: "'Sora', sans-serif" }}>{market.question}</div>
          </div>
          <button onClick={onClose} style={{ background: "#1e2736", border: "none", borderRadius: 8, color: "#64748b", width: 30, height: 30, cursor: "pointer", fontSize: 14, flexShrink: 0 }}>✕</button>
        </div>

        <div style={{ padding: "20px 24px" }}>
          {/* Stats row */}
          <div style={{ display: "flex", gap: 12, marginBottom: 24, flexWrap: "wrap" }}>
            {[
              { l: "Probabilité OUI", v: `${pct}%`, c: pct > 60 ? "#00e5a0" : pct > 40 ? "#f5c842" : "#ff4d6d" },
              { l: "Volume total", v: `$${formatVol(market.volume)}`, c: "#3b82f6" },
              { l: "Clôture", v: new Date(market.closes).toLocaleDateString("fr-FR", { day: "numeric", month: "short", year: "numeric" }), c: "#94a3b8" },
            ].map(s => (
              <div key={s.l} style={{ flex: 1, minWidth: 100, background: "#161b27", border: "1px solid #1e2736", borderRadius: 12, padding: "10px 14px", textAlign: "center" }}>
                <div style={{ fontSize: 18, fontWeight: 800, color: s.c, fontFamily: "'Space Mono', monospace" }}>{s.v}</div>
                <div style={{ fontSize: 10, color: "#4a5568", marginTop: 2 }}>{s.l}</div>
              </div>
            ))}
          </div>

          {/* Chart */}
          <div style={{ marginBottom: 24 }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: "#64748b", fontFamily: "'Space Mono', monospace", marginBottom: 10 }}>📈 ÉVOLUTION 30 JOURS</div>
            <div style={{ background: "#080c14", border: "1px solid #1e2736", borderRadius: 12, padding: "12px 8px 4px" }}>
              <ResponsiveContainer width="100%" height={140}>
                <LineChart data={market.history}>
                  <XAxis dataKey="day" tick={{ fontSize: 9, fill: "#4a5568", fontFamily: "'Space Mono', monospace" }} tickLine={false} axisLine={false} interval={9} />
                  <YAxis domain={[0, 100]} tick={{ fontSize: 9, fill: "#4a5568", fontFamily: "'Space Mono', monospace" }} tickLine={false} axisLine={false} tickFormatter={v => `${v}%`} width={32} />
                  <Tooltip content={<ChartTip />} />
                  <ReferenceLine y={50} stroke="#1e2736" strokeDasharray="4 4" />
                  <Line type="monotone" dataKey="prob" stroke="#00e5a0" strokeWidth={2} dot={false} activeDot={{ r: 4, fill: "#00e5a0" }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Bet section */}
          <div style={{ background: "#161b27", border: "1px solid #1e2736", borderRadius: 16, padding: "16px 18px", marginBottom: 24 }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: "#94a3b8", fontFamily: "'Space Mono', monospace", marginBottom: 12 }}>PLACER UN PARI</div>
            <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
              {["yes", "no"].map(s => (
                <button key={s} onClick={() => setSide(s)} style={{ flex: 1, padding: "10px 0", borderRadius: 10, border: `1px solid ${side === s ? (s === "yes" ? "#00e5a0" : "#ff4d6d") : "#1e2736"}`, background: side === s ? (s === "yes" ? "rgba(0,229,160,0.12)" : "rgba(255,77,109,0.12)") : "transparent", color: side === s ? (s === "yes" ? "#00e5a0" : "#ff4d6d") : "#64748b", fontWeight: 700, fontSize: 13, cursor: "pointer", fontFamily: "'Space Mono', monospace", transition: "all 0.2s" }}>
                  {s === "yes" ? "✓ OUI" : "✗ NON"}
                </button>
              ))}
            </div>
            <div style={{ display: "flex", gap: 8, marginBottom: 10 }}>
              {[5, 10, 25, 50].map(p => <button key={p} onClick={() => setAmount(p)} style={{ flex: 1, padding: "6px 0", borderRadius: 8, border: `1px solid ${amount === p ? "#00e5a0" : "#1e2736"}`, background: amount === p ? "rgba(0,229,160,0.08)" : "transparent", color: amount === p ? "#00e5a0" : "#64748b", fontSize: 12, fontWeight: 700, cursor: "pointer", fontFamily: "'Space Mono', monospace" }}>${p}</button>)}
            </div>
            <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 10 }}>
              <input type="number" min={1} value={amount} onChange={e => setAmount(+e.target.value)} style={{ flex: 1, background: "#0d1117", border: "1px solid #1e2736", borderRadius: 10, padding: "9px 12px", color: "#e2e8f0", fontSize: 14, fontFamily: "'Space Mono', monospace", outline: "none" }} />
              <button onClick={() => { onBet(market.id, side, amount); onClose(); }} style={{ padding: "9px 20px", background: side === "yes" ? "#00e5a0" : "#ff4d6d", color: "#000", border: "none", borderRadius: 10, fontWeight: 800, fontSize: 13, cursor: "pointer", fontFamily: "'Space Mono', monospace" }}>PARIER</button>
            </div>
            <div style={{ fontSize: 11, color: "#4a5568" }}>
              Gain potentiel : <span style={{ color: "#94a3b8", fontWeight: 600 }}>${side === "yes" ? (amount / market.yesProb).toFixed(2) : (amount / (1 - market.yesProb)).toFixed(2)}</span>
              &nbsp;•&nbsp; Côte : <span style={{ color: "#94a3b8", fontWeight: 600 }}>{side === "yes" ? (1 / market.yesProb).toFixed(2) : (1 / (1 - market.yesProb)).toFixed(2)}x</span>
            </div>
          </div>

          {/* AI Analysis */}
          <div style={{ background: "rgba(0,229,160,0.04)", border: "1px solid rgba(0,229,160,0.15)", borderRadius: 14, padding: "14px 16px", marginBottom: 24 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: aiAnalysis ? 10 : 0 }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: "#00e5a0", fontFamily: "'Space Mono', monospace" }}>✦ ANALYSE IA</div>
              {!aiAnalysis && !aiLoading && (
                <button onClick={getAiAnalysis} style={{ padding: "5px 14px", background: "rgba(0,229,160,0.12)", border: "1px solid rgba(0,229,160,0.3)", borderRadius: 8, color: "#00e5a0", fontSize: 11, fontWeight: 700, cursor: "pointer", fontFamily: "'Space Mono', monospace" }}>ANALYSER</button>
              )}
            </div>
            {aiLoading && <div style={{ fontSize: 13, color: "#4a5568", animation: "pulse 1s infinite" }}>Analyse en cours…</div>}
            {aiAnalysis && <div style={{ fontSize: 13, color: "#94a3b8", lineHeight: 1.6 }}>{aiAnalysis}</div>}
            {!aiAnalysis && !aiLoading && <div style={{ fontSize: 12, color: "#4a5568" }}>Cliquez pour obtenir une analyse IA du marché.</div>}
          </div>

          {/* Comments */}
          <div>
            <div style={{ fontSize: 12, fontWeight: 700, color: "#64748b", fontFamily: "'Space Mono', monospace", marginBottom: 12 }}>💬 COMMENTAIRES ({comments.length})</div>
            <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
              <input placeholder="Votre avis sur ce marché…" value={comment} onChange={e => setComment(e.target.value)} onKeyDown={e => e.key === "Enter" && addComment()}
                style={{ flex: 1, background: "#161b27", border: "1px solid #1e2736", borderRadius: 10, padding: "9px 12px", color: "#e2e8f0", fontSize: 13, fontFamily: "'Sora', sans-serif", outline: "none" }} />
              <button onClick={addComment} style={{ padding: "9px 16px", background: "#1e2736", border: "none", borderRadius: 10, color: "#94a3b8", fontSize: 13, cursor: "pointer", fontWeight: 700 }}>→</button>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {comments.map((c, i) => (
                <div key={i} style={{ background: "#161b27", border: "1px solid #1e2736", borderRadius: 12, padding: "12px 14px" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                    <span style={{ fontSize: 12, fontWeight: 700, color: "#00e5a0", fontFamily: "'Space Mono', monospace" }}>{c.user}</span>
                    <span style={{ fontSize: 11, color: "#4a5568" }}>{timeAgo(c.ts)}</span>
                  </div>
                  <div style={{ fontSize: 13, color: "#94a3b8", lineHeight: 1.5 }}>{c.text}</div>
                  <div style={{ marginTop: 8, fontSize: 11, color: "#4a5568" }}>👍 {c.likes}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── MARKET CARD ───────────────────────────────────────────────────────────────
function MarketCard({ market, onOpen, isNew }) {
  const pct = Math.round(market.yesProb * 100);
  const catColor = CAT_COLORS[market.category] || "#6b7280";
  return (
    <div onClick={() => onOpen(market)} style={{ background: "linear-gradient(135deg, #0d1117 0%, #161b27 100%)", border: `1px solid ${isNew ? "#00e5a0" : "#1e2736"}`, borderRadius: 16, padding: "18px 20px", cursor: "pointer", transition: "all 0.25s", boxShadow: isNew ? "0 0 20px rgba(0,229,160,0.15)" : "0 4px 20px rgba(0,0,0,0.3)", animation: isNew ? "fadeIn 0.5s ease" : "none", position: "relative" }}
      onMouseEnter={e => { e.currentTarget.style.borderColor = catColor + "60"; e.currentTarget.style.transform = "translateY(-2px)"; }}
      onMouseLeave={e => { e.currentTarget.style.borderColor = isNew ? "#00e5a0" : "#1e2736"; e.currentTarget.style.transform = "none"; }}>
      {isNew && <div style={{ position: "absolute", top: 10, right: 10, background: "#00e5a0", color: "#000", fontSize: 9, fontWeight: 700, padding: "2px 7px", borderRadius: 20, letterSpacing: 1, fontFamily: "'Space Mono', monospace" }}>NOUVEAU</div>}
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
        <span style={{ fontSize: 10, fontWeight: 700, color: catColor, background: `${catColor}18`, padding: "2px 8px", borderRadius: 20, fontFamily: "'Space Mono', monospace" }}>{market.category}</span>
        <span style={{ fontSize: 10, color: "#4a5568", marginLeft: "auto", fontFamily: "'Space Mono', monospace" }}>{new Date(market.closes).toLocaleDateString("fr-FR", { day: "numeric", month: "short" })}</span>
      </div>
      <p style={{ fontSize: 14, fontWeight: 600, color: "#e2e8f0", lineHeight: 1.5, marginBottom: 12, fontFamily: "'Sora', sans-serif" }}>{market.question}</p>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 8 }}>
        <div>
          <span style={{ fontSize: 28, fontWeight: 800, color: pct > 60 ? "#00e5a0" : pct > 40 ? "#f5c842" : "#ff4d6d", fontFamily: "'Space Mono', monospace", letterSpacing: -1 }}>{pct}%</span>
          <span style={{ fontSize: 11, color: "#4a5568", marginLeft: 5 }}>OUI</span>
        </div>
        <div style={{ textAlign: "right" }}>
          <div style={{ fontSize: 11, color: "#4a5568" }}>Vol.</div>
          <div style={{ fontSize: 13, fontWeight: 700, color: "#94a3b8", fontFamily: "'Space Mono', monospace" }}>${formatVol(market.volume)}</div>
        </div>
      </div>
      <ProbBar prob={market.yesProb} />
      <div style={{ display: "flex", justifyContent: "space-between", marginTop: 10 }}>
        {market.userBet && <span style={{ fontSize: 11, color: market.userBet.side === "yes" ? "#00e5a0" : "#ff4d6d", fontFamily: "'Space Mono', monospace" }}>Votre pari: {market.userBet.side.toUpperCase()} ${market.userBet.amount}</span>}
        <span style={{ fontSize: 11, color: "#4a5568", marginLeft: "auto" }}>💬 {market.comments?.length || 0} • Voir détails →</span>
      </div>
    </div>
  );
}

// ── LEADERBOARD ───────────────────────────────────────────────────────────────
function Leaderboard({ userStats }) {
  const board = [
    { rank: 1, user: "CryptoKing", avatar: "👑", profit: 4820, bets: 34, winRate: 71 },
    { rank: 2, user: "Stratège_Haïti", avatar: "🎯", profit: 3150, bets: 28, winRate: 64 },
    { rank: 3, user: "FutureVisor", avatar: "🔮", profit: 2740, bets: 19, winRate: 68 },
    { rank: 4, user: "TechOracle", avatar: "🤖", profit: 1990, bets: 41, winRate: 56 },
    { rank: 5, user: "MarketWizard", avatar: "🧙", profit: 1430, bets: 22, winRate: 59 },
    { rank: "—", user: "Vous", avatar: "😊", profit: userStats.profit, bets: userStats.bets, winRate: userStats.winRate, isYou: true },
  ];
  return (
    <div style={{ background: "#0d1117", border: "1px solid #1e2736", borderRadius: 20, overflow: "hidden" }}>
      <div style={{ padding: "18px 20px 14px", borderBottom: "1px solid #1e2736" }}>
        <div style={{ fontSize: 14, fontWeight: 800, color: "#e2e8f0", fontFamily: "'Space Mono', monospace" }}>🏆 CLASSEMENT</div>
        <div style={{ fontSize: 11, color: "#4a5568", marginTop: 2 }}>Meilleurs parieurs de la semaine</div>
      </div>
      {board.map((p, i) => (
        <div key={i} style={{ padding: "12px 20px", borderBottom: i < board.length - 1 ? "1px solid #1e2736" : "none", display: "flex", alignItems: "center", gap: 12, background: p.isYou ? "rgba(0,229,160,0.04)" : "transparent" }}>
          <div style={{ fontSize: 13, fontWeight: 800, color: i === 0 ? "#f5c842" : i === 1 ? "#94a3b8" : i === 2 ? "#cd7f32" : "#4a5568", width: 20, textAlign: "center", fontFamily: "'Space Mono', monospace" }}>{p.rank}</div>
          <div style={{ fontSize: 18 }}>{p.avatar}</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: p.isYou ? "#00e5a0" : "#e2e8f0", fontFamily: "'Sora', sans-serif" }}>{p.user}</div>
            <div style={{ fontSize: 10, color: "#4a5568" }}>{p.bets} paris • {p.winRate}% gagnés</div>
          </div>
          <div style={{ fontSize: 13, fontWeight: 800, color: p.profit >= 0 ? "#00e5a0" : "#ff4d6d", fontFamily: "'Space Mono', monospace" }}>+${p.profit}</div>
        </div>
      ))}
    </div>
  );
}

// ── TRANSACTION HISTORY ───────────────────────────────────────────────────────
function TxHistory({ transactions }) {
  if (!transactions.length) return (
    <div style={{ background: "#0d1117", border: "1px solid #1e2736", borderRadius: 20, padding: "32px", textAlign: "center" }}>
      <div style={{ fontSize: 28, marginBottom: 10 }}>📂</div>
      <div style={{ fontSize: 13, color: "#4a5568", fontFamily: "'Space Mono', monospace" }}>Aucune transaction</div>
    </div>
  );
  return (
    <div style={{ background: "#0d1117", border: "1px solid #1e2736", borderRadius: 20, overflow: "hidden" }}>
      <div style={{ padding: "18px 20px 14px", borderBottom: "1px solid #1e2736" }}>
        <div style={{ fontSize: 14, fontWeight: 800, color: "#e2e8f0", fontFamily: "'Space Mono', monospace" }}>📋 HISTORIQUE</div>
      </div>
      {transactions.slice().reverse().map((tx, i) => (
        <div key={i} style={{ padding: "12px 20px", borderBottom: i < transactions.length - 1 ? "1px solid #0d1117" : "none", display: "flex", alignItems: "center", gap: 12, background: "#0d1117" }}
          onMouseEnter={e => e.currentTarget.style.background = "#161b27"}
          onMouseLeave={e => e.currentTarget.style.background = "#0d1117"}>
          <div style={{ width: 36, height: 36, borderRadius: 10, background: tx.type === "deposit" ? "rgba(0,229,160,0.12)" : tx.side === "yes" ? "rgba(59,130,246,0.12)" : "rgba(255,77,109,0.12)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, flexShrink: 0 }}>
            {tx.type === "deposit" ? "💳" : tx.side === "yes" ? "✓" : "✗"}
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: "#e2e8f0", fontFamily: "'Sora', sans-serif", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
              {tx.type === "deposit" ? `Dépôt via ${tx.method}` : `Pari ${tx.side?.toUpperCase()} — ${tx.question}`}
            </div>
            <div style={{ fontSize: 11, color: "#4a5568", marginTop: 2 }}>{timeAgo(tx.ts)}</div>
          </div>
          <div style={{ fontSize: 13, fontWeight: 800, fontFamily: "'Space Mono', monospace", color: tx.type === "deposit" ? "#00e5a0" : "#ff4d6d", flexShrink: 0 }}>
            {tx.type === "deposit" ? "+" : "-"}${tx.amount}
          </div>
        </div>
      ))}
    </div>
  );
}

// ── MAIN APP ──────────────────────────────────────────────────────────────────
export default function PredictMarket() {
  const [markets, setMarkets] = useState(INIT_MARKETS);
  const [balance, setBalance] = useState(500);
  const [transactions, setTransactions] = useState([]);
  const [generating, setGenerating] = useState(false);
  const [genError, setGenError] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [category, setCategory] = useState("Tous");
  const [newIds, setNewIds] = useState([]);
  const [topic, setTopic] = useState("");
  const [showDeposit, setShowDeposit] = useState(false);
  const [detailMarket, setDetailMarket] = useState(null);
  const [activeTab, setActiveTab] = useState("markets"); // markets | leaderboard | history
  const [currentUser] = useState("Vous");
  const nextId = useRef(markets.length + 1);

  const categories = ["Tous", "Sport", "Technologie", "Finance", "Politique", "Science", "Culture"];
  const filtered = markets.filter(m => (category === "Tous" || m.category === category) && m.question.toLowerCase().includes(searchTerm.toLowerCase()));

  const totalBets = markets.filter(m => m.userBet).length;
  const invested = markets.filter(m => m.userBet).reduce((s, m) => s + m.userBet.amount, 0);
  const userStats = { profit: Math.floor(Math.random() * 200), bets: totalBets, winRate: totalBets ? Math.floor(55 + Math.random() * 20) : 0 };

  async function generateMarkets() {
    setGenerating(true); setGenError("");
    const prompt = topic ? `Génère 3 marchés prédictifs sur : "${topic}".` : "Génère 3 marchés prédictifs variés sur l'actualité mondiale.";
    try {
      const res = await fetch(CLAUDE_API, {
        method: "POST", headers: { "Content-Type": "application/json", "x-api-key": API_KEY, "anthropic-version": "2023-06-01", "anthropic-dangerous-direct-browser-access": "true" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514", max_tokens: 800,
          messages: [{ role: "user", content: `${prompt}\nRéponds UNIQUEMENT en JSON valide sans texte ni backticks:\n[\n  {"question":"...","category":"Sport|Technologie|Finance|Politique|Science|Culture","yesProb":0.XX,"volume":NNNN,"closes":"YYYY-MM-DD"}\n]\n- yesProb 0.05-0.95, volume 5000-500000, closes 2026-2028, questions en français précises et mesurables` }]
        })
      });
      const data = await res.json();
      const raw = data.content?.find(b => b.type === "text")?.text || "[]";
      const parsed = JSON.parse(raw.replace(/```json|```/g, "").trim());
      const added = parsed.map((m, i) => ({ ...m, id: nextId.current + i, userBet: null, comments: [], history: genHistory(m.yesProb) }));
      nextId.current += parsed.length;
      setMarkets(prev => [...added, ...prev]);
      setNewIds(added.map(m => m.id));
      setTimeout(() => setNewIds([]), 5000);
      setTopic("");
    } catch { setGenError("Erreur de génération."); }
    setGenerating(false);
  }

  function handleBet(marketId, side, amount) {
    if (amount > balance) { setGenError("Solde insuffisant !"); setTimeout(() => setGenError(""), 3000); return; }
    const mkt = markets.find(m => m.id === marketId);
    setBalance(b => b - amount);
    setMarkets(prev => prev.map(m => m.id === marketId
      ? { ...m, userBet: { side, amount }, volume: m.volume + amount, yesProb: side === "yes" ? Math.min(0.95, m.yesProb + 0.01) : Math.max(0.05, m.yesProb - 0.01) }
      : m
    ));
    setTransactions(prev => [...prev, { type: "bet", side, amount, question: mkt?.question?.slice(0, 40) + "…", ts: Date.now() }]);
  }

  function handleDeposit(amount) {
    setBalance(b => b + amount);
    setTransactions(prev => [...prev, { type: "deposit", amount, method: "Paiement", ts: Date.now() }]);
  }

  const TABS = [{ id: "markets", label: "Marchés", icon: "◈" }, { id: "leaderboard", label: "Classement", icon: "🏆" }, { id: "history", label: "Historique", icon: "📋" }];

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Sora:wght@300;400;600;700;800&family=Space+Mono:wght@400;700&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { background: #080c14; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(-12px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.4} }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-track { background: #0d1117; }
        ::-webkit-scrollbar-thumb { background: #1e2736; border-radius: 4px; }
        input::-webkit-inner-spin-button { -webkit-appearance: none; }
        input[type=number] { -moz-appearance: textfield; }
      `}</style>

      {showDeposit && <DepositModal onClose={() => setShowDeposit(false)} onDeposit={handleDeposit} />}
      {detailMarket && <MarketDetail market={detailMarket} onClose={() => setDetailMarket(null)} onBet={handleBet} currentUser={currentUser} />}

      <div style={{ minHeight: "100vh", background: "#080c14", fontFamily: "'Sora', sans-serif" }}>

        {/* HEADER */}
        <div style={{ position: "sticky", top: 0, zIndex: 100, background: "rgba(8,12,20,0.95)", backdropFilter: "blur(20px)", borderBottom: "1px solid #1e2736" }}>
          <div style={{ maxWidth: 960, margin: "0 auto", padding: "0 20px" }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", height: 62 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <div style={{ width: 32, height: 32, borderRadius: 8, background: "linear-gradient(135deg, #00e5a0, #3b82f6)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 15 }}>◈</div>
                <span style={{ fontSize: 17, fontWeight: 800, color: "#e2e8f0", fontFamily: "'Space Mono', monospace", letterSpacing: -0.5 }}>PRÉDICT</span>
                <span style={{ fontSize: 10, color: "#4a5568", background: "#161b27", border: "1px solid #1e2736", borderRadius: 6, padding: "2px 7px", fontFamily: "'Space Mono', monospace" }}>BETA</span>
              </div>
              <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                {totalBets > 0 && <span style={{ fontSize: 11, color: "#4a5568", fontFamily: "'Space Mono', monospace", display: "none" }}>{totalBets} paris</span>}
                <button onClick={() => setShowDeposit(true)} style={{ padding: "6px 13px", background: "transparent", border: "1px solid #1e2736", borderRadius: 9, color: "#94a3b8", fontSize: 11, cursor: "pointer", fontFamily: "'Space Mono', monospace", fontWeight: 700, transition: "all 0.2s" }}
                  onMouseEnter={e => { e.currentTarget.style.borderColor = "#00e5a0"; e.currentTarget.style.color = "#00e5a0"; }}
                  onMouseLeave={e => { e.currentTarget.style.borderColor = "#1e2736"; e.currentTarget.style.color = "#94a3b8"; }}>+ DÉPÔT</button>
                <div onClick={() => setShowDeposit(true)} style={{ background: "linear-gradient(135deg, #00e5a018, #3b82f618)", border: "1px solid #00e5a030", borderRadius: 9, padding: "5px 13px", fontFamily: "'Space Mono', monospace", fontSize: 13, fontWeight: 700, cursor: "pointer" }}>
                  <span style={{ color: "#4a5568" }}>$</span><span style={{ color: "#00e5a0" }}>{balance.toFixed(0)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div style={{ maxWidth: 960, margin: "0 auto", padding: "28px 20px" }}>

          {/* HERO */}
          <div style={{ textAlign: "center", marginBottom: 36 }}>
            <div style={{ display: "inline-block", fontSize: 10, fontWeight: 700, color: "#00e5a0", background: "rgba(0,229,160,0.08)", border: "1px solid rgba(0,229,160,0.2)", borderRadius: 20, padding: "3px 12px", marginBottom: 14, fontFamily: "'Space Mono', monospace", letterSpacing: 2 }}>PROPULSÉ PAR CLAUDE AI</div>
            <h1 style={{ fontSize: "clamp(26px, 5vw, 44px)", fontWeight: 800, color: "#e2e8f0", lineHeight: 1.15, marginBottom: 10, fontFamily: "'Space Mono', monospace", letterSpacing: -1 }}>
              Pariez sur<br />
              <span style={{ background: "linear-gradient(90deg, #00e5a0, #3b82f6)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>le futur</span>
            </h1>
            <p style={{ fontSize: 14, color: "#64748b", lineHeight: 1.6 }}>Marchés prédictifs IA • PayPal • MonCash • NatCash • Carte</p>
          </div>

          {/* ERROR */}
          {genError && <div style={{ background: "rgba(255,77,109,0.1)", border: "1px solid rgba(255,77,109,0.3)", borderRadius: 10, padding: "10px 16px", marginBottom: 18, fontSize: 13, color: "#ff4d6d", fontFamily: "'Space Mono', monospace" }}>{genError}</div>}

          {/* DEPOSIT CTA */}
          <div style={{ background: "linear-gradient(135deg, #0d1117, #111827)", border: "1px solid #1e2736", borderRadius: 18, padding: "18px 22px", marginBottom: 18, display: "flex", alignItems: "center", gap: 16, flexWrap: "wrap" }}>
            <div style={{ flex: 1, minWidth: 180 }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: "#94a3b8", fontFamily: "'Space Mono', monospace", marginBottom: 6 }}>💳 DÉPÔTS ACCEPTÉS</div>
              <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                {PAYMENT_METHODS.map(pm => <span key={pm.id} style={{ fontSize: 10, color: "#64748b", background: "#161b27", border: "1px solid #1e2736", borderRadius: 6, padding: "2px 8px" }}>{pm.icon} {pm.name}</span>)}
              </div>
            </div>
            <button onClick={() => setShowDeposit(true)} style={{ padding: "10px 20px", background: "linear-gradient(135deg, #00e5a0, #3b82f6)", color: "#000", border: "none", borderRadius: 10, fontWeight: 800, fontSize: 12, cursor: "pointer", fontFamily: "'Space Mono', monospace", whiteSpace: "nowrap" }}>DÉPOSER →</button>
          </div>

          {/* AI GENERATOR */}
          <div style={{ background: "linear-gradient(135deg, #0d1117, #111827)", border: "1px solid #1e2736", borderRadius: 18, padding: "20px 22px", marginBottom: 28, position: "relative", overflow: "hidden" }}>
            <div style={{ position: "absolute", top: -30, right: -30, width: 100, height: 100, borderRadius: "50%", background: "radial-gradient(circle, rgba(0,229,160,0.07) 0%, transparent 70%)" }} />
            <div style={{ fontSize: 12, fontWeight: 700, color: "#94a3b8", marginBottom: 12, fontFamily: "'Space Mono', monospace" }}>✦ GÉNÉRER DES MARCHÉS AVEC L'IA</div>
            <div style={{ display: "flex", gap: 10 }}>
              <input placeholder="Thème optionnel (élections, crypto, sport…)" value={topic} onChange={e => setTopic(e.target.value)} onKeyDown={e => e.key === "Enter" && generateMarkets()}
                style={{ flex: 1, background: "#0d1117", border: "1px solid #1e2736", borderRadius: 10, padding: "10px 14px", color: "#e2e8f0", fontSize: 13, fontFamily: "'Sora', sans-serif", outline: "none" }} />
              <button onClick={generateMarkets} disabled={generating} style={{ padding: "10px 20px", background: generating ? "#1e2736" : "linear-gradient(135deg, #00e5a0, #3b82f6)", color: generating ? "#4a5568" : "#000", border: "none", borderRadius: 10, fontWeight: 800, fontSize: 12, cursor: generating ? "not-allowed" : "pointer", fontFamily: "'Space Mono', monospace", whiteSpace: "nowrap" }}>
                {generating ? <span style={{ animation: "pulse 1s infinite", display: "inline-block" }}>…</span> : "GÉNÉRER ✦"}
              </button>
            </div>
          </div>

          {/* TABS */}
          <div style={{ display: "flex", gap: 4, marginBottom: 24, background: "#0d1117", border: "1px solid #1e2736", borderRadius: 12, padding: 4 }}>
            {TABS.map(t => (
              <button key={t.id} onClick={() => setActiveTab(t.id)} style={{ flex: 1, padding: "9px 0", borderRadius: 9, border: "none", background: activeTab === t.id ? "#1e2736" : "transparent", color: activeTab === t.id ? "#e2e8f0" : "#4a5568", fontWeight: 700, fontSize: 12, cursor: "pointer", fontFamily: "'Sora', sans-serif", transition: "all 0.2s" }}>
                {t.icon} {t.label}
              </button>
            ))}
          </div>

          {/* MARKETS TAB */}
          {activeTab === "markets" && (
            <>
              {/* Stats */}
              <div style={{ display: "flex", gap: 12, marginBottom: 20, flexWrap: "wrap" }}>
                {[
                  { label: "Marchés", val: markets.length, color: "#00e5a0" },
                  { label: "Volume", val: `$${formatVol(markets.reduce((s, m) => s + m.volume, 0))}`, color: "#3b82f6" },
                  { label: "Vos paris", val: totalBets, color: "#f5c842" },
                  { label: "Engagé", val: `$${invested}`, color: "#a855f7" },
                ].map(s => (
                  <div key={s.label} style={{ flex: 1, minWidth: 80, background: "#0d1117", border: "1px solid #1e2736", borderRadius: 12, padding: "10px 14px", textAlign: "center" }}>
                    <div style={{ fontSize: 18, fontWeight: 800, color: s.color, fontFamily: "'Space Mono', monospace" }}>{s.val}</div>
                    <div style={{ fontSize: 10, color: "#4a5568", marginTop: 2 }}>{s.label}</div>
                  </div>
                ))}
              </div>

              {/* Filters */}
              <div style={{ display: "flex", gap: 10, marginBottom: 20, flexWrap: "wrap", alignItems: "center" }}>
                <input placeholder="🔍 Rechercher…" value={searchTerm} onChange={e => setSearchTerm(e.target.value)}
                  style={{ flex: 1, minWidth: 180, background: "#0d1117", border: "1px solid #1e2736", borderRadius: 10, padding: "8px 14px", color: "#e2e8f0", fontSize: 13, fontFamily: "'Sora', sans-serif", outline: "none" }} />
                <div style={{ display: "flex", gap: 5, flexWrap: "wrap" }}>
                  {categories.map(cat => (
                    <button key={cat} onClick={() => setCategory(cat)} style={{ padding: "6px 12px", borderRadius: 8, fontSize: 11, fontWeight: 600, cursor: "pointer", background: category === cat ? "#00e5a0" : "#0d1117", color: category === cat ? "#000" : "#64748b", border: `1px solid ${category === cat ? "#00e5a0" : "#1e2736"}`, transition: "all 0.15s" }}>{cat}</button>
                  ))}
                </div>
              </div>

              {/* Market grid */}
              {filtered.length === 0
                ? <div style={{ textAlign: "center", padding: "60px 0", color: "#4a5568" }}><div style={{ fontSize: 32, marginBottom: 10 }}>◌</div><div style={{ fontFamily: "'Space Mono', monospace" }}>Aucun marché</div></div>
                : <div style={{ display: "grid", gap: 14 }}>{filtered.map(m => <MarketCard key={m.id} market={m} onOpen={setDetailMarket} isNew={newIds.includes(m.id)} />)}</div>
              }
            </>
          )}

          {/* LEADERBOARD TAB */}
          {activeTab === "leaderboard" && <Leaderboard userStats={userStats} />}

          {/* HISTORY TAB */}
          {activeTab === "history" && <TxHistory transactions={transactions} />}

          <div style={{ textAlign: "center", marginTop: 44, color: "#1e2736", fontSize: 10, fontFamily: "'Space Mono', monospace" }}>PRÉDICT • Marchés simulés à des fins éducatives</div>
        </div>
      </div>
    </>
  );
}
